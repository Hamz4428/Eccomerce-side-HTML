if (window && window.navigator && window.navigator.connection) {
  var connection = window.navigator.connection;
  connection.addEventListener('change', function(){
    console.log("Connection type was changed");
  });
}
